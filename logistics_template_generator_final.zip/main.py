from logic_learner import learn_template_logic
from template_generator import generate_templates
from pathlib import Path

# Paths
example_contract_path = "examples/contract_data.xlsx"
template_folder = "examples/templates"
new_contract_path = "examples/contract_data.xlsx"  # For testing, using same contract
output_folder = "output"

# Step 1: Learn logic from examples
logic_summary = learn_template_logic(example_contract_path, template_folder)
print("\n🧠 Learned Template Logic:")
print(logic_summary)

# Step 2: Generate new templates
generated_paths = generate_templates(new_contract_path, logic_summary, output_folder)
print("\n✅ Generated Templates:")
for path in generated_paths:
    print(f"  - {path}")
